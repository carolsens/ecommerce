 <!-- jQuery -->
 <script src="<?= BASE_URL_VENDORS_BACKEND ?>/jquery/dist/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <!-- FastClick -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/fastclick/lib/fastclick.js"></script>
  <!-- NProgress -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/nprogress/nprogress.js"></script>
  <!-- Chart.js -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Chart.js/dist/Chart.min.js"></script>
  <!-- gauge.js -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/gauge.js/dist/gauge.min.js"></script>
  <!-- bootstrap-progressbar -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
  <!-- iCheck -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/iCheck/icheck.min.js"></script>
  <!-- Skycons -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/skycons/skycons.js"></script>
  <!-- Flot -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Flot/jquery.flot.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Flot/jquery.flot.pie.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Flot/jquery.flot.time.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Flot/jquery.flot.stack.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/Flot/jquery.flot.resize.js"></script>
  <!-- Flot plugins -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/flot.orderbars/js/jquery.flot.orderBars.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/flot-spline/js/jquery.flot.spline.min.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/flot.curvedlines/curvedLines.js"></script>
  <!-- DateJS -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/DateJS/build/date.js"></script>
  <!-- JQVMap -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/jqvmap/dist/jquery.vmap.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/jqvmap/dist/maps/jquery.vmap.world.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
  <!-- bootstrap-daterangepicker -->
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/moment/min/moment.min.js"></script>
  <script src="<?= BASE_URL_VENDORS_BACKEND ?>/bootstrap-daterangepicker/daterangepicker.js"></script>

  <!-- Custom Theme Scripts -->
  <script src="<?= BASE_URL_BUILD_BACKEND ?>/js/custom.min.js"></script>


<!-- bootstrap-wysiwyg -->
<script src="<?= BASE_URL_VENDORS_BACKEND ?>/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js"></script>
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/jquery.hotkeys/jquery.hotkeys.js"></script>
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/google-code-prettify/src/prettify.js"></script>

    	<!-- jQuery Tags Input -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/jquery.tagsinput/src/jquery.tagsinput.js"></script>
	<!-- Switchery -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/switchery/dist/switchery.min.js"></script>
	<!-- Select2 -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/select2/dist/js/select2.full.min.js"></script>
	<!-- Parsley -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/parsleyjs/dist/parsley.min.js"></script>
	<!-- Autosize -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/autosize/dist/autosize.min.js"></script>
	<!-- jQuery autocomplete -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/devbridge-autocomplete/dist/jquery.autocomplete.min.js"></script>
	<!-- starrr -->
	<script src="<?= BASE_URL_VENDORS_BACKEND ?>/starrr/dist/starrr.js"></script>


  <script src="<?= BASE_URL_JS_BACKEND ?>/script.js"></script>

    
	<script src="<?= BASE_URL_JS_BACKEND ?>/scriptbackend.js"></script>
	<script src="<?= BASE_URL_LIBS_BACKEND ?>/jquery.maskMoney.min.js"></script>



	

	
