<?php

include(__DIR__ . DIRECTORY_SEPARATOR . 'init.php');
include($adminBaseDir  . DIRECTORY_SEPARATOR . 'includes/protect.php');